package stu.tnt.ai;

import stu.tnt.ai.kbs.KnowledgeBase;
import stu.tnt.ai.kbs.data.DataBool;
import stu.tnt.ai.kbs.data.DataNumb;
import stu.tnt.gdx.utils.ArrayDeque;
import alice.tuprologx.ide.CUIConsole;

public class tuPrologTest {
	public static void main(String[] args) {
		KnowledgeBase kbs = new KnowledgeBase();
		
	}
}
