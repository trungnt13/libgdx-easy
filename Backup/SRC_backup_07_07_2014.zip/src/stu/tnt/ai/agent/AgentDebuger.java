package stu.tnt.ai.agent;

import stu.tnt.gdx.utils.D;

public class AgentDebuger {
	public static void log(String s) {
		D.out(s);
	}
}
