package stu.tnt.gdx.core.loader;

public interface Unload
{
    public void unload ();
}
