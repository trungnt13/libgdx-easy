package stu.tnt.gdx.core.loader;


public interface Load
{
    public void load ();
}
