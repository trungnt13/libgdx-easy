package stu.tnt.gdx.widget.callback;

import com.badlogic.gdx.scenes.scene2d.Actor;



public interface  OnValueListener {
	public void ValueChanged(Actor actor,float value);
}