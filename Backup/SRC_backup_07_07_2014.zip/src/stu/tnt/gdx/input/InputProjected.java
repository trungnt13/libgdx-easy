package stu.tnt.gdx.input;

import com.badlogic.gdx.InputProcessor;

public interface InputProjected extends InputProcessor{
	
}
