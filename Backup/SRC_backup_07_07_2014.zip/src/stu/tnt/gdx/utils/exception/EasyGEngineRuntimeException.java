package stu.tnt.gdx.utils.exception;

public class EasyGEngineRuntimeException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6374736600981084546L;
	
	public EasyGEngineRuntimeException(){
		super();
	}
	
	public EasyGEngineRuntimeException(String msg){
		super(msg);
	}
}
