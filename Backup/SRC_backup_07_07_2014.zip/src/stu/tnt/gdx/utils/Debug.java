package stu.tnt.gdx.utils;

public interface Debug
{
    public String info ();
}
