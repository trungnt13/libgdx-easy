package stu.tnt.gdx.utils;

public interface Debugable
{
    public String info ();
}
