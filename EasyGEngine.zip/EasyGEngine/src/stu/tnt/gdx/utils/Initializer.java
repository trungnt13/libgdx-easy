package stu.tnt.gdx.utils;

public interface Initializer {
	public void init();
}
