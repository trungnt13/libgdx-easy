package stu.tnt.gdx.utils;

public interface Charge {
	public void run(Object obj, float delta);
}