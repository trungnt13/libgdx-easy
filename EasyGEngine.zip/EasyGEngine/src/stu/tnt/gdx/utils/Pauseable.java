package stu.tnt.gdx.utils;

public interface Pauseable {
	public void Pause();
	
	public void Resume();
}
