package stu.tnt.gdx.utils;


public interface OnRecycleListener<T> {
	public void RecycleObject(T recycleObject);
}

