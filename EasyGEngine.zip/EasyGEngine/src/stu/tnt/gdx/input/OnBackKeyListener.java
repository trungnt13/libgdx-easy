package stu.tnt.gdx.input;

public interface OnBackKeyListener {
	public boolean BackKeyPressed();
}
