package stu.tnt.gdx.core.loader;

public interface UnloadedCallback
{
    public void unloaded (String name, Class type);
}
