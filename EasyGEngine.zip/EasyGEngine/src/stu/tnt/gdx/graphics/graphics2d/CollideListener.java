package stu.tnt.gdx.graphics.graphics2d;


public interface CollideListener {
	public void Collided (SpriteBackend s1, SpriteBackend s2);
}
