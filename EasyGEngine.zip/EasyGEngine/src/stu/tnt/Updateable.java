package stu.tnt;

public interface Updateable {
	public void update(float delta);
}
